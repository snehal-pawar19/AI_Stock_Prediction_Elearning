from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, g
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
import yfinance as yf
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from datetime import datetime, timedelta
import os
import sqlite3
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 1. Initialize application
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

# 2. Get absolute path to root directory
# This ensures site.db is created in the same folder as app.py
basedir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(basedir, 'site.db')

# 3. Configure SQLAlchemy with absolute path
# sqlite:/// + absolute path (Windows requires 3 slashes if path starts with C:\)
db_uri = 'sqlite:///' + db_path.replace('\\', '/')
app.config['SQLALCHEMY_DATABASE_URI'] = db_uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 4. Initialize SQLAlchemy
db = SQLAlchemy(app)

# 5. Create beginner-friendly raw database connection function
def get_db():
    if 'db_conn' not in g:
        try:
            # Connect to the absolute database path
            g.db_conn = sqlite3.connect(db_path, timeout=15)
            # This allows accessing columns by name: row['username']
            g.db_conn.row_factory = sqlite3.Row
        except sqlite3.Error as e:
            logger.error(f"Database connection error: {e}")
            return None
    return g.db_conn

# 6. Ensure raw database closes properly
@app.teardown_appcontext
def close_db(error):
    db_conn = g.pop('db_conn', None)
    if db_conn is not None:
        db_conn.close()

bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# 7. Database Models
class User(db.Model, UserMixin):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    balance = db.Column(db.Float, default=10000.0)
    learning_level = db.Column(db.String(20), default='Beginner')
    holdings = db.relationship('Portfolio', backref='owner', lazy=True)
    trades = db.relationship('Transaction', backref='user', lazy=True)
    quiz_scores = db.relationship('QuizScore', backref='user', lazy=True)

class QuizScore(db.Model):
    __tablename__ = 'quiz_score'
    id = db.Column(db.Integer, primary_key=True)
    score = db.Column(db.Integer, nullable=False)
    total = db.Column(db.Integer, nullable=False)
    level = db.Column(db.String(20), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Portfolio(db.Model):
    __tablename__ = 'portfolio'
    id = db.Column(db.Integer, primary_key=True)
    stock_symbol = db.Column(db.String(10), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    buy_price = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Transaction(db.Model):
    __tablename__ = 'transaction'
    id = db.Column(db.Integer, primary_key=True)
    stock_symbol = db.Column(db.String(10), nullable=False)
    type = db.Column(db.String(10), nullable=False) # 'buy' or 'sell'
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

# ====================================================
# DATABASE INITIALIZATION (MUST BE AFTER MODELS)
# ====================================================
def init_db(force_recreate=False):
    """Initialize the database and create tables if they don't exist."""
    with app.app_context():
        try:
            print(f"DEBUG: Database path is {db_path}")
            if force_recreate:
                print("DEBUG: Dropping all tables for a clean state...")
                db.drop_all()
            
            db.create_all()
            logger.info(f"Database initialized successfully at: {db_path}")
            
            # Verify if 'user' table exists
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            tables = inspector.get_table_names()
            print(f"DEBUG: Tables in database: {tables}")
            
            if 'user' not in tables:
                print("CRITICAL ERROR: 'user' table was NOT created!")
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")

# Run initialization (set force_recreate=True only when resetting)
init_db(force_recreate=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, email=email, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Fetch leaderboard (top 5 users by balance)
    leaderboard = User.query.order_by(User.balance.desc()).limit(5).all()
    
    # Pass current_user and leaderboard to the template
    return render_template('dashboard.html', user=current_user, leaderboard=leaderboard)

@app.route('/profile')
@login_required
def profile():
    quiz_history = QuizScore.query.filter_by(user_id=current_user.id).order_by(QuizScore.timestamp.desc()).all()
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.timestamp.desc()).all()
    trade_count = len(transactions)
    
    # Gamification Badge Logic
    badges = []
    if trade_count >= 1: 
        badges.append({'name': 'First Trade', 'icon': 'fa-seedling', 'color': 'text-success'})
    if trade_count >= 10: 
        badges.append({'name': 'Active Trader', 'icon': 'fa-bolt', 'color': 'text-warning'})
    if any(q.score == q.total for q in quiz_history): 
        badges.append({'name': 'Quiz Master', 'icon': 'fa-crown', 'color': 'text-warning'})
    if current_user.balance > 10000: 
        badges.append({'name': 'Profit Maker', 'icon': 'fa-money-bill-trend-up', 'color': 'text-success'})
    
    return render_template('profile.html', user=current_user, quiz_history=quiz_history, transactions=transactions, trade_count=trade_count, badges=badges)

@app.route('/market_summary')
def market_summary():
    """Provides market gainers/losers with fallback data to ensure dashboard loads."""
    symbols = ['RELIANCE.NS', 'TCS.NS', 'HDFCBANK.NS', 'INFY.NS', 'ICICIBANK.NS', 'BHARTIARTL.NS', 'SBIN.NS', 'LICI.NS', 'ITC.NS', 'HUL.NS']
    
    all_data = []
    for s in symbols:
        try:
            stock = yf.Ticker(s)
            hist = stock.history(period='2d')
            if len(hist) >= 2:
                curr = hist['Close'].iloc[-1]
                prev = hist['Close'].iloc[-2]
                change = round(((curr - prev) / prev) * 100, 2)
                all_data.append({
                    'symbol': s.replace('.NS', ''),
                    'price': round(curr, 2),
                    'change': change
                })
        except Exception as e:
            logger.warning(f"Error fetching {s}: {e}")
            continue
    
    # Ensure we return SOMETHING even if yfinance fails
    if not all_data:
        all_data = [{'symbol': 'NIFTY50', 'price': 22000, 'change': 0.5}]
        
    gainers = sorted(all_data, key=lambda x: x['change'], reverse=True)[:5]
    losers = sorted(all_data, key=lambda x: x['change'])[:5]
    
    return jsonify({
        'gainers': gainers,
        'losers': losers,
        'all': all_data
    })

@app.route('/prediction.html')
@login_required
def prediction_page():
    return render_template('prediction.html')

@app.route('/learning.html')
@login_required
def learning_page():
    return render_template('learning.html')

@app.route('/quiz.html')
@login_required
def quiz_page():
    return render_template('quiz.html')

@app.route('/get_stock_data', methods=['POST'])
@login_required
def get_stock_data():
    data = request.json
    symbol = data.get('symbol', '').upper()
    if not symbol:
        return jsonify({'success': False, 'error': 'Symbol is required'})
    
    try:
        stock = yf.Ticker(symbol)
        info = stock.history(period='1d')
        if info.empty:
            return jsonify({'success': False, 'error': 'Invalid symbol or no data found'})
        
        current_data = info.iloc[-1]
        return jsonify({
            'success': True,
            'symbol': symbol,
            'current_price': round(current_data['Close'], 2),
            'open': round(current_data['Open'], 2),
            'high': round(current_data['High'], 2),
            'low': round(current_data['Low'], 2)
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/predict', methods=['POST'])
@login_required
def predict():
    data = request.json
    symbol = data.get('symbol', 'AAPL').upper()
    
    try:
        # 1. Fetch historical stock data using Yahoo Finance
        stock = yf.Ticker(symbol)
        hist = stock.history(period="1y")
        
        if hist.empty:
            return jsonify({'success': False, 'error': 'No data found for symbol'})

        # 2. Preprocess dataset
        df = hist[['Close', 'Open', 'High', 'Low', 'Volume']].copy()
        df['Next_Close'] = df['Close'].shift(-1)
        df.dropna(inplace=True)

        # Features (Open, High, Low, Volume) to predict next day's Close
        X = df[['Close', 'Open', 'High', 'Low', 'Volume']]
        y = df['Next_Close']
        
        # 3. Train Linear Regression model
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        model = LinearRegression()
        model.fit(X_train, y_train)

        # 4. Predict next closing price
        last_data = hist[['Close', 'Open', 'High', 'Low', 'Volume']].iloc[-1:].values
        predicted_price = model.predict(last_data)[0]
        
        # Calculate confidence (using R2 score on test set)
        y_pred_test = model.predict(X_test)
        confidence = round(r2_score(y_test, y_pred_test) * 100, 2)
        if confidence < 0: confidence = 0 # Ensure confidence is non-negative
        if confidence > 99: confidence = 99.8 # Capping for realism
        
        trend_30 = hist['Close'].tail(30).tolist()
        dates_30 = [d.strftime('%Y-%m-%d') for d in hist.index[-30:]]
        
        current_price = hist['Close'].iloc[-1]
        percent_change = ((predicted_price - current_price) / current_price) * 100
        
        # 5. Return prediction to frontend with Trend (Bullish/Bearish)
        trend_label = "Bullish (Increase)" if predicted_price > current_price else "Bearish (Decrease)"

        # 6. Generate AI Explanations/Insights
        insights = []
        avg_volume = df['Volume'].mean()
        last_volume = hist['Volume'].iloc[-1]
        
        if last_volume > avg_volume * 1.5:
            insights.append("High volume indicates strong market interest.")
        elif last_volume < avg_volume * 0.5:
            insights.append("Low volume suggests cautious trading sentiment.")
            
        if current_price > df['Close'].mean():
            insights.append("Stock is currently trading above its yearly average.")
        else:
            insights.append("Stock is currently trading below its yearly average.")
            
        if predicted_price > current_price:
            insights.append(f"AI model detects an upward momentum for {symbol}.")
        else:
            insights.append(f"AI model suggests a potential downward correction for {symbol}.")

        return jsonify({
            'success': True,
            'symbol': symbol,
            'current_price': round(current_price, 2),
            'predicted_price': round(predicted_price, 2),
            'percent_change': round(percent_change, 2),
            'trend': trend_label,
            'confidence': confidence,
            'insights': insights,
            'history': trend_30,
            'dates': dates_30
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/trade', methods=['POST'])
@login_required
def trade():
    data = request.json
    action = data.get('action')
    symbol = data.get('symbol').upper()
    quantity = int(data.get('quantity', 0))
    
    try:
        stock = yf.Ticker(symbol)
        current_price = stock.history(period="1d")['Close'].iloc[-1]
        total_value = current_price * quantity

        if action == 'buy':
            if current_user.balance >= total_value:
                current_user.balance -= total_value
                holding = Portfolio.query.filter_by(user_id=current_user.id, stock_symbol=symbol).first()
                if holding:
                    total_qty = holding.quantity + quantity
                    holding.buy_price = ((holding.buy_price * holding.quantity) + total_value) / total_qty
                    holding.quantity = total_qty
                else:
                    new_holding = Portfolio(stock_symbol=symbol, quantity=quantity, buy_price=current_price, user_id=current_user.id)
                    db.session.add(new_holding)
                
                trade_log = Transaction(stock_symbol=symbol, type='buy', quantity=quantity, price=current_price, user_id=current_user.id)
                db.session.add(trade_log)
                db.session.commit()
                return jsonify({'success': True, 'message': f'Bought {quantity} shares of {symbol}', 'balance': round(current_user.balance, 2)})
            else:
                return jsonify({'success': False, 'error': 'Insufficient balance'})
        
        elif action == 'sell':
            holding = Portfolio.query.filter_by(user_id=current_user.id, stock_symbol=symbol).first()
            if holding and holding.quantity >= quantity:
                current_user.balance += total_value
                holding.quantity -= quantity
                if holding.quantity == 0:
                    db.session.delete(holding)
                
                trade_log = Transaction(stock_symbol=symbol, type='sell', quantity=quantity, price=current_price, user_id=current_user.id)
                db.session.add(trade_log)
                db.session.commit()
                return jsonify({'success': True, 'message': f'Sold {quantity} shares of {symbol}', 'balance': round(current_user.balance, 2)})
            else:
                return jsonify({'success': False, 'error': 'Insufficient shares'})
                
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/portfolio', methods=['GET'])
@login_required
def get_portfolio():
    """Returns user portfolio with real-time value and safety checks."""
    try:
        holdings = Portfolio.query.filter_by(user_id=current_user.id).all()
        holdings_list = []
        total_holdings_value = 0
        
        for h in holdings:
            try:
                stock = yf.Ticker(h.stock_symbol)
                hist = stock.history(period="1d")
                if not hist.empty:
                    curr = hist['Close'].iloc[-1]
                else:
                    curr = h.buy_price # Fallback to buy price if live data fails
                    
                profit_loss = (curr - h.buy_price) * h.quantity
                holdings_list.append({
                    'symbol': h.stock_symbol,
                    'quantity': h.quantity,
                    'avg_price': round(h.buy_price, 2),
                    'current_price': round(curr, 2),
                    'pl': round(profit_loss, 2)
                })
                total_holdings_value += (curr * h.quantity)
            except Exception as e:
                logger.warning(f"Portfolio fetch error for {h.stock_symbol}: {e}")
                continue
                
        return jsonify({
            'success': True,
            'balance': round(current_user.balance, 2),
            'total_value': round(current_user.balance + total_holdings_value, 2),
            'holdings': holdings_list
        })
    except Exception as e:
        logger.error(f"Global portfolio error: {e}")
        return jsonify({'success': False, 'error': 'Could not load portfolio data'})

@app.route('/recommend', methods=['POST'])
@login_required
def recommend():
    data = request.json
    score = data.get('score', 0)
    total = data.get('total', 5)
    percentage = (score / total) * 100

    if percentage > 70:
        level = 'Advanced'
        msg = "Impressive! You have a strong grasp of market dynamics. Ready for advanced strategies."
    elif percentage >= 40:
        level = 'Intermediate'
        msg = "Good progress! You're ready to explore technical analysis and chart patterns."
    else:
        level = 'Beginner'
        msg = "Great start! Let's build your foundation with market essentials and terminology."

    current_user.learning_level = level
    
    # Store the quiz result in database
    quiz_result = QuizScore(score=score, total=total, level=level, user_id=current_user.id)
    db.session.add(quiz_result)
    db.session.commit()

    return jsonify({
        'level': level,
        'message': msg,
        'score': score
    })

if __name__ == '__main__':
    # Final check for database tables before starting the server
    with app.app_context():
        try:
            db.create_all()
            logger.info("Database tables verified.")
        except Exception as e:
            logger.error(f"Startup database check failed: {e}")
            
    app.run(debug=True, port=5000)
