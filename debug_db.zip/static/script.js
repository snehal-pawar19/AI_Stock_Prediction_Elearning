// Dummy historical stock data
const dates = ["2026-03-01", "2026-03-02", "2026-03-03", "2026-03-04", "2026-03-05", "2026-03-06", "2026-03-07", "2026-03-08", "2026-03-09", "2026-03-10", "2026-03-11", "2026-03-12", "2026-03-13", "2026-03-14", "2026-03-15", "2026-03-16"];
const prices = [150.2, 152.5, 148.9, 155.6, 158.2, 160.1, 157.5, 159.8, 162.4, 165.0, 163.2, 168.5, 172.1, 170.5, 174.2, 178.0];

document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById("stockChart").getContext('2d');

    // Create gradient for the line
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(46, 204, 113, 0.4)');
    gradient.addColorStop(1, 'rgba(46, 204, 113, 0)');

    new Chart(ctx, {
        type: "line",
        data: {
            labels: dates,
            datasets: [{
                label: "Stock Price ($)",
                data: prices,
                borderColor: "#2ecc71",
                backgroundColor: gradient,
                fill: true,
                borderWidth: 3,
                tension: 0.4, // Smoothing the line
                pointRadius: 4,
                pointBackgroundColor: "#2ecc71",
                pointHoverRadius: 6,
                pointHoverBackgroundColor: "#fff"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: '#bdc3c7',
                        font: {
                            family: "'Poppins', sans-serif",
                            size: 14
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#1a202e',
                    titleColor: '#fff',
                    bodyColor: '#bdc3c7',
                    borderColor: '#2ecc71',
                    borderWidth: 1,
                    displayColors: false,
                    padding: 10
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    },
                    ticks: {
                        color: '#bdc3c7',
                        font: {
                            family: "'Poppins', sans-serif"
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)'
                    },
                    ticks: {
                        color: '#bdc3c7',
                        font: {
                            family: "'Poppins', sans-serif"
                        },
                        callback: function(value) {
                            return '$' + value;
                        }
                    }
                }
            }
        }
    });
});
